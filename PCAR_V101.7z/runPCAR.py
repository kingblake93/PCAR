import tkinter as tk
import os, sys
import subprocess
import PCAR_Settings as PST

root = tk.Tk()
root.title("Window title")
root.geometry("600x500")

text = tk.Text(root)
text.insert(tk.END,open('Copyright.txt','r').read())
text.pack(side = "top", fill = "both", expand = "yes")
text.config(state=tk.DISABLED)

def runPCAR():
    if os.path.exists('./PCAR.pyc'):
        subprocess.call([os.getenv('PY3'), 'PCAR.pyc'])
    else:
        subprocess.call([os.getenv('PY3'), 'PCAR.py'])

frame = tk.Frame(root)
frame.pack()
buttonAgree = tk.Button(frame,
                   text="Agree",
                   fg="green",
                   command=runPCAR)
buttonAgree.pack(side=tk.LEFT)
buttonExit = tk.Button(frame, 
                   text="Exit", 
                   fg="red",
                   command=quit)
buttonExit.pack(side=tk.LEFT)

root.mainloop()

