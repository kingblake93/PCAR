import mhrc.automation
import os, sys

print ('*************************************************')
print ('********   PsCadAutoRun by Xiaoyu Wang   ********')
print ('********              ERCOT              ********')
print ('*************************************************')

os.environ['PY2'] = "C:\python27\python.exe"
os.environ['PY3'] = "C:\Program Files\Python37\python.exe"


## Extensions ####
pscadExt = '.pscx'
pslibExt = '.pslx'
fortranExt = '.if12'
xlsxExt = '.xlsx'
slaveSmbl = '_SL'
slaveCsEnd = slaveSmbl + pscadExt
masterSmbl = '_Master'
masterCsEnd = masterSmbl + pscadExt
pyExt = '.py'
savExt = '.sav'
epBkExt = '.epbx'
epWbkExt = '.epwx'
infExt = '.inf'
outExt = '.out'

## PSCAD Settings ####
controller = mhrc.automation.controller()
pscad_versions = controller.get_paramlist_names('pscad')
fortran_versions = controller.get_paramlist_names('fortran')
pscad_version = pscad_versions[1]
fortran_version = fortran_versions[0]
certificate=0


## Common Variables ####
EtranLib = r'C:\Program Files (x86)\E-TRAN_V4\PSCADLib\ETRAN.pslx'
cmpNameDic = {
            "PRLLe":"\\cmp_PRLLe" + xlsxExt, 
            "SCR":"\\cmp_SCR" + xlsxExt, 
            "VDW":"\\cmp_VDW" + xlsxExt, 
            "VUP":"\\cmp_VUP" + xlsxExt, 
            "HVRT":"\\cmp_HVRT" + xlsxExt, 
            "LVRT":"\\cmp_LVRT" + xlsxExt, 
            "ADW":"\\cmp_ADW" + xlsxExt, 
            "AUP":"\\cmp_AUP" + xlsxExt}
cmpUpdNameDic = {
            "PRLLe":"\\cmpUpdated_PRLLe" + xlsxExt, 
            "SCR":"\\cmpUpdated_SCR" + xlsxExt}

psseOut = "O:\\Xiaoyu\\Work\\2019\\06_PAN2020\\Models\\PSSE\\Version 2.2\\RESULTs"
#psseOut = "O:\\Xiaoyu\\Work\\2019\\06_PAN2020\\DMView2.0_2.2\\RESULTs"
psseFsFldName = 'TEST1_FS_FS'
psseVdwFldName = 'TEST2_ERUN_VOLT'
psseVupFldName = 'TEST3_ERUN+_VOLT'
psseLvrtFldName = 'TEST5_LVRT_VOLT'
psseHvrtFldName = 'TEST4_HVRT_VOLT'
psseScrFldName = 'TEST6_SCR2_SCR2'
psseScrFileName = 'TEST6_SCR2_SCR2_5-3-1.5-1'
psseVch345Name = 'VOLT  88888 [POI         345.00]' 
psseVch138Name = 'VOLT  88888 [POI         138.00]' 
#psseVch345Name = 'VOLT  88888 [TEMP        345.00]' 
#psseVch138Name = 'VOLT  88888 [TEMP        138.00]'
pssePchName = 'P TIE LINE 88888 TO 99999 CKT 1' 
psseQchName = 'Q TIE LINE 88888 TO 99999 CKT 1'
psseInfiPch345Name = 'POWR 99999[INFI        345.00]1' 
psseInfiQch345Name = 'VARS 99999[INFI        345.00]1' 
psseInfiPch138Name = 'POWR 99999[INFI        138.00]1' 
psseInfiQch138Name = 'VARS 99999[INFI        138.00]1'
#psseInfiPch345Name = 'POWR 99999[INF        345.00]1' 
#psseInfiQch345Name = 'VARS 99999[INF        345.00]1'
#psseInfiPch345Name = 'POWR 99999[INF         345.00]1' 
#psseInfiQch345Name = 'VARS 99999[INF         345.00]1'  
#psseInfiPch138Name = 'POWR 99999[INF         138.00]1' 
#psseInfiQch138Name = 'VARS 99999[INF         138.00]1'


######################### Testing Flags ####
PRLLe_flag = 0

SCR_Advanced_flag = 0
SCR_flag = 1
VDW_flag = 1
VUP_flag = 1
LVRT_flag = 1
HVRT_flag = 1
ADW_flag = 1
AUP_flag = 1

masterCsSkip_flag = 0
savePlot_flag = 1
compPsse_flag = 0


############################################################# PRLLe Settings ####

simTimePRLLe = 30
dltSLoutSecFlag = 0
pfImSecFlag = 0
cmplSlSecFlag  = 0
dltSLif12MstrFlag = 0
runSecFlag = 1

dltSLif12SLFlag = 0
compileQutFlag = 1

pfImPyName = "imPFpy2"
pfDirName = "PSSE"
pfCaseName = "2022_HWLL_Final_NonCnv33_NNL_PH80NP100_WK"
pfDataName = "pfData"
   
mvaBase = 100
smnsSize2p415 = 2.415
smnsSize2p3 = 2.3
phDisLevel = 0.8
npDisLevel = 1
maxGenNum = 6

#cmplRngS = 11 # starts from 0
#cmplRngE = 12

ctgRngS = 19 # starts from 1, set 0 for flat start
ctgRngE = 20

############################################################# SCRa Settings ####
simTimeSCRa = 40

############################################################# SCR Settings ####
simTimeSCR = 0.050
#scrRngS = 11
#scrRngE = 12
epXminSCR = 5
epXmaxSCR = 50

############################################################# VDW Settings ####
simTimeVDW = 0.020
#vdwRngS = 11
#vdwRngE = 12
epXminVDW = 5
epXmaxVDW = 20

############################################################# VUP Settings ####
simTimeVUP = 0.020
#vupRngS = 11
#vupRngE = 12
epXminVUP = 5
epXmaxVUP = 20

############################################################# LVRT Settings ####
simTimeLVRT = 0.030
#lvrtRngS = 11
#lvrtRngE = 12
epXminLVRT = 5
epXmaxLVRT = 30

############################################################# HVRT Settings ####
simTimeHVRT = 0.030
#hvrtRngS = 11
#hvrtRngE = 12
epXminHVRT = 5
epXmaxHVRT = 30

############################################################# ADW Settings ####
simTimeADW = 0.020
#adwRngS = 11
#adwRngE = 12
epXminADW = 5
epXmaxADW = 20

############################################################# AUP Settings ####
simTimeAUP = 0.020
#aupRngS = 11
#aupRngE = 12
epXminAUP = 5
epXmaxAUP = 20


############################################################# Settings Imported ####


print (60*'_')
print ('Settings Imported.')










