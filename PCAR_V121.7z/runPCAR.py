
import tkinter as tk
import os, sys
import subprocess

root = tk.Tk()
root.title("PCAR Initialization")
root.geometry("600x500")

text = tk.Text(root)
text.insert(tk.END,open('./Copyright.txt','r').read())
text.pack(side = "top", fill = "both", expand = "yes")
text.config(state=tk.DISABLED)

def popPCARgui():
    if os.path.exists('./guiPCAR.pyc'):
        subprocess.call([sys.executable, './guiPCAR.pyc'])
    else:
        subprocess.call([sys.executable, './guiPCAR.py'])
frame = tk.Frame(root)
frame.pack()
btnAgree = tk.Button(frame,
                   text="AGREE",
                   fg="green",
                   command=popPCARgui)
btnAgree.pack(side=tk.LEFT)
btnExit = tk.Button(frame, 
                   text="EXIT", 
                   fg="red",
                   command=quit)
btnExit.pack(side=tk.LEFT)

root.mainloop()

