#!/usr/bin/env python3

import tkinter as tk
import os, sys
import subprocess

root = tk.Tk()
root.title("PCAR Initialization")
root.geometry("600x500")

text = tk.Text(root)
text.insert(tk.END,open('./Resources/Copyright.txt','r').read())
text.pack(side = "top", fill = "both", expand = "yes")
text.config(state=tk.DISABLED)

def popPCARgui():
    if os.path.exists('./Resources/guiPCAR.pyc'):
        subprocess.call([sys.executable, './Resources/guiPCAR.pyc'])
    else:
        subprocess.call([sys.executable, './Resources/guiPCAR.py'])
frame = tk.Frame(root)
frame.pack()
btnAgree = tk.Button(frame,
                   text="AGREE",
                   fg="green",
                   command=popPCARgui)
btnAgree.pack(side=tk.LEFT)
btnExit = tk.Button(frame, 
                   text="EXIT", 
                   fg="red",
                   command=quit)
btnExit.pack(side=tk.LEFT)

root.mainloop()

